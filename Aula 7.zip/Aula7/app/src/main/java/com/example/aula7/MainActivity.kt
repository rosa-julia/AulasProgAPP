package com.example.aula7

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Achar os ids que vamos usar
        val dadoInserido = findViewById<EditText>(R.id.dadoInserido)
        val botaoSalvar = findViewById<Button>(R.id.botaoSalvar)
        val textoSalvo = findViewById<TextView>(R.id.textoSalvo)

        //Consumir nosso sharedpreference

        val sharedPreference = getSharedPreferences("MINHAS_PREFERENCIAS", Context.MODE_PRIVATE)

        botaoSalvar.setOnClickListener {
            val dadoDigitado = dadoInserido.text.toString()
            textoSalvo.text = dadoDigitado
            dadoInserido.text.clear() //limpar o campo

           val editor = sharedPreference.edit() //edita o sharedpreference
           editor.putString("dado", dadoDigitado)
           editor.apply() //salvar
        }

        val dadoPersistido = sharedPreference.getString("dado", "")

        if(!dadoPersistido.isNullOrBlank()){
            textoSalvo.text = "Dado Salvo: $dadoPersistido"
        }
    }
}